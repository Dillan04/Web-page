import React, { useState } from 'react';
import Dashboard from './Dashboard';

function StudentRegistration({ onLoginClick }) {
  const [userData, setUserData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    studentId: '',
    password: '',
    age: '',
    course: '', // Add course property
  });
  const [isFormCompleted, setIsFormCompleted] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setUserData((prevUserData) => ({
      ...prevUserData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsFormCompleted(true);
  };

  const handleBackToLoginClick = () => {
    onLoginClick();
  };

  return (
    <div
      style={{
        background: 'linear-gradient(to top, #0080ff, #ffffff)',
        textAlign: 'center',
        borderRadius: '10px',
        padding: '20px',
        color: 'black', // Change text color to black
      }}
    >
      {!isFormCompleted ? (
        <>
          <h1 style={{ color: 'black' }}>Student Registration</h1> {/* Change text color to black */}
          <form onSubmit={handleSubmit}>
            <div>
              <label>First Name: </label>
              <input
                type="text"
                name="firstName"
                value={userData.firstName}
                onChange={handleInputChange}
              />
            </div>
            <div>
              <label>Last Name: </label>
              <input
                type="text"
                name="lastName"
                value={userData.lastName}
                onChange={handleInputChange}
              />
            </div>
            <div>
              <label>Email: </label>
              <input
                type="email"
                name="email"
                value={userData.email}
                onChange={handleInputChange}
              />
            </div>
            <div>
              <label>Student ID: </label>
              <input
                type="text"
                name="studentId"
                value={userData.studentId}
                onChange={handleInputChange}
              />
            </div>
            <div>
              <label>Password: </label>
              <input
                type="password"
                name="password"
                value={userData.password}
                onChange={handleInputChange}
              />
            </div>
            <div>
              <label>Age: </label>
              <input
                type="number"
                name="age"
                value={userData.age}
                onChange={handleInputChange}
              />
            </div>
            <div>
              <label>Course: </label>
              <input
                type="text"
                name="course"
                value={userData.course}
                onChange={handleInputChange}
              />
            </div>
            <button type="submit">Next</button>
          </form>
          <p>
            Already have an account?{' '}
            <button onClick={handleBackToLoginClick}>Go to Login</button>
          </p>
        </>
      ) : (
        <Dashboard userData={userData} onBackToLoginClick={handleBackToLoginClick} />
      )}
    </div>
  );
}

export default StudentRegistration;
