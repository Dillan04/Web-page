import React, { useState } from 'react';
import logo from './UoG.png'; // Import your logo image file

function LoginPage({ onRegistrationLinkClick, onLogin }) {
  const [studentId, setStudentId] = useState('');
  const [password, setPassword] = useState('');

  const handleStudentIdChange = (e) => {
    setStudentId(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleLogin = (e) => {
    e.preventDefault();
    // Add your login logic here
    console.log('Student ID:', studentId);
    console.log('Password:', password);
    onLogin();
  };

  const handleRegistrationLinkClick = () => {
    onRegistrationLinkClick(); // Invoke the callback to switch to the student registration page
  };

  return (
    <div
      style={{
        background: 'linear-gradient(to top, #0080ff, #ffffff)',
        textAlign: 'center',
        borderRadius: '10px', // Add rounded corners
        padding: '20px', // Add some padding
      }}
      className="slide-in" // Add the CSS class for slide-in animation
    >
      <img src={logo} alt="Logo" style={{ width: '100px', marginBottom: '10px' }} /> {/* Add your logo image */}
      <h1 style={{ color: 'black' }}>Welcome to University of Ghana Student Login Page</h1>
      <h1 style={{ color: 'black' }}>Login To Access Student Info</h1>
      <form onSubmit={handleLogin}>
        <div>
          <label style={{ color: 'black' }}>Student ID: </label>
          <input type="text" value={studentId} onChange={handleStudentIdChange} />
        </div>
        <div>
          <label style={{ color: 'black' }}>Password: </label>
          <input type="password" value={password} onChange={handlePasswordChange} />
        </div>
        <button type="submit">Login</button>
        <p>
          Do not have an account?{' '}
          <button onClick={handleRegistrationLinkClick}>Click here</button> to register as a student.
        </p>
      </form>
    </div>
  );
}

export default LoginPage;
