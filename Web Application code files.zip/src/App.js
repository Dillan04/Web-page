import React, { useState } from 'react';
import './App.css';
import LoginPage from './LoginPage';
import StudentRegistration from './StudentRegistration';
import Dashboard from './Dashboard';

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [userData, setUserData] = useState(null);

  const handleLogin = () => {
    setLoggedIn(true);
  };

  const handleBackToLoginClick = () => {
    setLoggedIn(false);
    setUserData(null); // Reset the user data
  };

  const handleUserDataUpdate = (data) => {
    setUserData(data);
    setLoggedIn(true); // Set loggedIn to true after getting user data
  };

  const handleRegistrationLinkClick = () => {
    setLoggedIn(false);
    setUserData(null); // Reset the user data
  };

  return (
    <div className="App">
      {!loggedIn ? (
        <LoginPage onLogin={handleLogin} onRegistrationLinkClick={handleRegistrationLinkClick} />
      ) : (
        userData ? (
          <Dashboard userData={userData} onBackToLoginClick={handleBackToLoginClick} />
        ) : (
          <StudentRegistration onLoginClick={handleBackToLoginClick} onUserDataUpdate={handleUserDataUpdate} />
        )
      )}
    </div>
  );
}

export default App;
