function Dashboard({ userData, onBackToLoginClick }) {
  const handleBackToLoginClick = () => {
    onBackToLoginClick(); 
  };

  return (
    <div>
      <h1 style={{ fontWeight: 'bold', fontSize: '28px', color: 'black' }}>WELCOME</h1> {/* This makes the text bolder, sizeable, and black */}
      <p>
        <strong style={{ fontWeight: 'bold', fontSize: '22px' }}>Welcome to The University of Ghana, Legon!</strong> <br />
        This is your user data from your registration:
        <br />
        <strong>First Name: </strong> {userData.firstName}
        <br />
        <strong>Last Name: </strong> {userData.lastName}
        <br />
        <strong>Email: </strong> {userData.email}
        <br />
        <strong>Student ID: </strong> {userData.studentId}
        <br />
        <strong>Age: </strong> {userData.age} {/* This displays the age */}
        <br />
        <strong>Course: </strong> {userData.course} {/* This displays the course information */}
      </p>
      <button onClick={handleBackToLoginClick}>Register Another User</button>
    </div>
  );
}

export default Dashboard;
